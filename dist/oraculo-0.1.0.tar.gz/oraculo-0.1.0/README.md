# Oráculo 

Uma aplicação em CLI e WebApp para *Semantic Search*

