import typer
import subprocess
import chromadb
from rich import print


app = typer.Typer()


@app.command()
def init():
    print(":crystal_ball: Hi there, this is [bold blue]Mana![/bold blue]")
    
# emojis
# :wizard:
# :crystal_ball:
# :sparkles:
# :star2:


@app.command()
def webapp():
    subprocess.run(["streamlit", "run", "webapp/hello_world.py"])


@app.command()
def vectordb():
    # initialize the database
    db = chromadb.ChromaDB("chromadb.db")

    

if __name__ == "__main__":
    app()